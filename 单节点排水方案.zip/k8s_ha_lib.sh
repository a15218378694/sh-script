#!/bin/bash
#===============================================
# K8S高可用演练 - 公共函数库
# 所有脚本通过 source 引用此文件
#===============================================

# 自动扫描所有命名空间（排除系统命名空间）
# 用法: get_all_namespaces
get_all_namespaces() {
    # 获取所有命名空间并排除系统命名空间
    kubectl get namespace -o jsonpath='{.items[*].metadata.name}' 2>/dev/null | \
        tr ' ' '\n' | \
        grep -v '^$' | \
        grep -v '^kube-system$' | \
        grep -v '^kube-public$' | \
        grep -v '^kube-node-lease$' | \
        grep -v '^system$'
}

# 动态获取指定命名空间下所有 Deployment 名称
# 用法: get_all_deployments <namespace>
get_all_deployments() {
    local ns="$1"
    kubectl get deployment -n "$ns" -o jsonpath='{.items[*].metadata.name}' 2>/dev/null | tr ' ' '\n' | grep -v '^$'
}

# 获取所有命名空间下的所有 Deployment 名称（去重）
# 用法: get_all_deployments_all_ns [数组名]
# 如果不提供数组名，则输出到stdout（兼容旧用法）
get_all_deployments_all_ns() {
    local output
    output=$(while IFS= read -r ns; do
        [ -z "$ns" ] && continue
        while IFS= read -r dep; do
            [ -n "$dep" ] && echo "$ns/$dep"
        done < <(get_all_deployments "$ns")
    done < <(get_all_namespaces) | sort -u)
    
    if [ -n "$1" ]; then
        # 如果提供了数组名，使用nameref赋值
        local -n __out="$1"
        __out=()
        while IFS= read -r line; do
            __out+=("$line")
        done <<< "$output"
    else
        # 否则输出到stdout
        echo "$output"
    fi
}

# 获取 Deployment 当前副本数
# 用法: get_replicas <namespace> <deployment>
get_replicas() {
    local ns="$1"
    local dep="$2"
    kubectl get deployment "$dep" -n "$ns" \
        --request-timeout="${KUBECTL_TIMEOUT}s" \
        -o jsonpath='{.spec.replicas}' 2>/dev/null
}

# 获取 Deployment 的 Running Pod 数量
# 用法: get_running_pods_count <namespace> <deployment>
get_running_pods_count() {
    local ns="$1"
    local dep="$2"
    kubectl get pods -n "$ns" -l app="$dep" \
        --field-selector status.phase=Running \
        --no-headers 2>/dev/null | wc -l | tr -d ' '
}

# 检查 Deployment 是否存在
# 用法: deploy_exists <namespace> <deployment>
deploy_exists() {
    local ns="$1"
    local dep="$2"
    kubectl get deployment "$dep" -n "$ns" &>/dev/null
}

# 检查 Service 是否存在
# 用法: svc_exists <namespace> <service>
svc_exists() {
    local ns="$1"
    local svc="$2"
    kubectl get svc "$svc" -n "$ns" &>/dev/null
}

# 遍历所有命名空间执行命令的辅助函数
# 用法: for_each_namespace <function_name> [args...]
for_each_namespace() {
    local func="$1"
    shift
    while IFS= read -r ns; do
        [ -z "$ns" ] && continue
        "$func" "$ns" "$@"
    done < <(get_all_namespaces)
}

#===============================================
# 基础服务检查函数
#===============================================

# 检查节点上的 kubelet 和 docker 服务状态
# 用法: check_node_services <node_name>
check_node_services() {
    local node="$1"
    echo "[INFO] 检查节点 $node 的基础服务..."
    
    # 通过 kubectl node-shell 或 SSH 检查（这里用 kubectl get node 间接检查）
    # 实际生产中应通过 Ansible/SSH 登录节点检查
    # 这里提供框架，具体实现需根据环境调整
    
    # 示例：检查节点是否 Ready
    local node_status
    node_status=$(kubectl get node "$node" --no-headers 2>/dev/null | awk '{print $2}')
    if [ "$node_status" = "Ready" ]; then
        echo "  ✓ 节点 $node 状态: Ready"
    else
        echo "  ✗ 节点 $node 状态异常: $node_status"
    fi
    
    # 如果需要检查 kubelet/docker，可以取消注释以下代码（需要 SSH 或 node-shell）
    # kubectl node-shell "$node" -- systemctl status kubelet 2>/dev/null
    # kubectl node-shell "$node" -- systemctl status docker 2>/dev/null
}

# 检查节点上的 EP 端口（Etcd Peer 端口）
# 用法: check_ep_ports <node_name>
check_ep_ports() {
    local node="$1"
    echo "[INFO] 检查节点 $node 的 EP 端口..."
    
    # EP 端口通常指 Etcd Peer 端口（2380）或其他关键端口
    # 这里检查节点上的关键端口是否监听
    
    # 示例：检查 kubelet 端口（10250）
    if kubectl get node "$node" --no-headers &>/dev/null; then
        echo "  ✓ 节点 $node 可访问"
    else
        echo "  ✗ 节点 $node 不可访问"
    fi
    
    # 如果需要检查具体端口，可以取消注释（需要网络访问或 SSH）
    # kubectl node-shell "$node" -- ss -tlnp | grep -E '(:10250|:2380|:6443)'
}

# 检查集群基础组件状态
# 用法: check_cluster_components
check_cluster_components() {
    echo "[INFO] 检查集群基础组件..."
    
    # 检查 Etcd
    local etcd_status
    etcd_status=$(kubectl get pod -n kube-system -l component=etcd --no-headers 2>/dev/null | grep -c Running || echo "0")
    if [ "$etcd_status" -ge 1 ]; then
        echo "  ✓ Etcd 组件正常 ($etcd_status 个 Pod Running)"
    else
        echo "  ✗ Etcd 组件异常"
    fi
    
    # 检查 API Server
    if kubectl cluster-info &>/dev/null; then
        echo "  ✓ API Server 正常"
    else
        echo "  ✗ API Server 异常"
    fi
    
    # 检查 Controller Manager
    local cm_status
    cm_status=$(kubectl get pod -n kube-system -l component=kube-controller-manager --no-headers 2>/dev/null | grep -c Running || echo "0")
    if [ "$cm_status" -ge 1 ]; then
        echo "  ✓ Controller Manager 正常 ($cm_status 个 Pod Running)"
    else
        echo "  ✗ Controller Manager 异常"
    fi
    
    # 检查 Scheduler
    local sched_status
    sched_status=$(kubectl get pod -n kube-system -l component=kube-scheduler --no-headers 2>/dev/null | grep -c Running || echo "0")
    if [ "$sched_status" -ge 1 ]; then
        echo "  ✓ Scheduler 正常 ($sched_status 个 Pod Running)"
    else
        echo "  ✗ Scheduler 异常"
    fi
}
