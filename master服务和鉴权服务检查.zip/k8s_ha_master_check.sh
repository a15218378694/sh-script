#!/bin/bash
#===============================================
# K8S高可用 - Master节点服务检查脚本（ansible-agent版）
# 功能：通过 ansible-agent 远程检查 master 节点核心服务
# 检查项：etcd、kube-apiserver、kube-controller-manager、kube-scheduler
# 用法: k8s_ha_master_check.sh <master_node_ip>
# 输出：最后一行输出0（成功）/1（失败）
#===============================================
# 生产环境不建议使用 set -e，改为显式错误处理：

# 颜色定义
RED='\033[31m'
GREEN='\033[32m'
YELLOW='\033[33m'
BLUE='\033[34m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step() { echo -e "${BLUE}[STEP]${NC} $1"; }

# 检查项计数
CHECK_PASS=0
CHECK_WARN=0
CHECK_FAIL=0

check_item() {
    local desc="$1"
    local status="$2"
    case "$status" in
        pass)
            echo -e "  ✓ $desc"
            CHECK_PASS=$((CHECK_PASS + 1))
            ;;
        warn)
            echo -e "  ⚠ $desc"
            CHECK_WARN=$((CHECK_WARN + 1))
            ;;
        fail)
            echo -e "  ✗ $desc"
            CHECK_FAIL=$((CHECK_FAIL + 1))
            ;;
    esac
}

# 通过 ansible-agent 远程执行命令
# 用法: remote_exec "<命令>"
remote_exec() {
    local cmd="$1"
    ansible-agent -H "${MASTER_IP}" exec -a "${cmd}" 2>/dev/null
}

# 检查 systemd 服务状态，异常时自动重启
# 用法: check_and_restart_service <服务名> <显示名>
check_and_restart_service() {
    local service_name="$1"
    local display_name="$2"
    
    # 第一次检查
    local status_output
    status_output=$(remote_exec "systemctl is-active ${service_name}")
    
    if [ "$status_output" = "active" ]; then
        check_item "${display_name} 服务运行正常（active）" "pass"
        return
    fi
    
    # 服务异常，尝试重启
    echo "  ⚠ ${display_name} 服务异常（${status_output:-执行失败}），正在重启..."
    remote_exec "systemctl restart ${service_name}"
    
    # 重启后循环检查是否启动，最多3次，每次5秒
    RESTART_OK=0
    for i in 1 2 3; do
        echo "  [INFO] 第 ${i} 次检查：${display_name} 服务状态 ..."
        sleep 5
        status_output=$(remote_exec "systemctl is-active ${service_name}")
        if [ "$status_output" = "active" ]; then
            echo "  [INFO] 第 ${i} 次检查通过（active）"
            RESTART_OK=1
            break
        fi
    done
    
    if [ "$RESTART_OK" -eq 1 ]; then
        check_item "${display_name} 重启后恢复正常（共尝试 ${i} 次）" "pass"
    else
        check_item "${display_name} 重启失败（尝试3次均未active），请手动排查" "fail"
    fi
}

#===============================================
# 主流程
#===============================================
echo "============================================"
echo "    K8S Master节点服务检查（ansible-agent）"
echo "============================================"
echo "检查时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 检查参数
if [ -z "$1" ]; then
    echo "用法: $0 <master_node_ip>"
    echo "示例: $0 10.234.6.21"
    echo "1"
    exit 1
fi

MASTER_IP="$1"

# 预检查：ansible-agent 是否可用
log_step "【0】预检查：ansible-agent 连接"
echo ""
if ! command -v ansible-agent &>/dev/null; then
    check_item "ansible-agent 命令不存在" "fail"
    echo "1"
    exit 1
fi
check_item "ansible-agent 命令可用" "pass"

AGENT_CHECK=$(remote_exec "hostname")
if [ -z "$AGENT_CHECK" ]; then
    check_item "ansible-agent 连接到 $MASTER_IP 失败" "fail"
    echo "1"
    exit 1
fi
check_item "ansible-agent 连接到 $MASTER_IP 成功（主机名: $AGENT_CHECK）" "pass"
echo ""

#--------------------------------------------
# 1. 检查 etcd 服务
#--------------------------------------------
log_step "【1】检查 etcd 服务状态"
echo ""
check_and_restart_service "etcd" "etcd"
echo ""

#--------------------------------------------
# 2. 检查 kube-apiserver 服务
#--------------------------------------------
log_step "【2】检查 kube-apiserver 服务状态"
echo ""
check_and_restart_service "kube-apiserver" "kube-apiserver"
echo ""

#--------------------------------------------
# 3. 检查 kube-controller-manager 服务
#--------------------------------------------
log_step "【3】检查 kube-controller-manager 服务状态"
echo ""
check_and_restart_service "kube-controller-manager" "kube-controller-manager"
echo ""

#--------------------------------------------
# 4. 检查 kube-scheduler 服务
#--------------------------------------------
log_step "【4】检查 kube-scheduler 服务状态"
echo ""
check_and_restart_service "kube-scheduler" "kube-scheduler"
echo ""

#--------------------------------------------
# 总结与输出
#--------------------------------------------
echo "============================================"
echo "    检查完成: $MASTER_IP"
echo "    通过: $CHECK_PASS"
echo "    警告: $CHECK_WARN"
echo "    失败: $CHECK_FAIL"
echo "============================================"

if [ "$CHECK_FAIL" -eq 0 ]; then
    echo "0"
    exit 0
else
    echo "1"
    exit 1
fi
