#!/bin/bash
#===============================================
# K8S高可用恢复脚本（兜底恢复）
# 功能：演练后的全量恢复（兜底所有未恢复的节点、还原配置等）
# 输出：最后一行输出0（成功）/1（失败）
#===============================================

# 生产环境不建议使用 set -e，改为显式错误处理

# 导入统一配置和公共函数库
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${SCRIPT_DIR}/k8s_ha_config.sh"
source "${SCRIPT_DIR}/k8s_ha_lib.sh"

# 动态获取所有命名空间下的所有 Deployment（格式: namespace/deployment）
HA_DRILL_ALL=()
while IFS= read -r ns; do
    [ -z "$ns" ] && continue
    while IFS= read -r dep; do
        [ -n "$dep" ] && HA_DRILL_ALL+=("$ns/$dep")
    done < <(get_all_deployments "$ns")
done < <(get_all_namespaces)

echo "============================================"
echo "    K8S高可用恢复（兜底恢复）"
echo "============================================"
echo "开始时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "命名空间: $(get_all_namespaces | tr '\n' ' ')"
echo "需要恢复的Deployment:"
for item in "${HA_DRILL_ALL[@]}"; do
    echo "  - $item"
done
echo ""

OVERALL_SUCCESS=0

# 1. 兜底恢复所有被cordon的节点
echo "[STEP] 兜底恢复所有不可调度节点"
UNCORDON_COUNT=0
for node in $(kubectl get nodes --no-headers 2>/dev/null | grep SchedulingDisabled | awk '{print $1}'); do
    echo "[INFO] 恢复节点: $node"
    kubectl uncordon $node 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "[INFO] 节点 $node 已恢复调度"
        UNCORDON_COUNT=$((UNCORDON_COUNT + 1))
    fi
done
if [ "$UNCORDON_COUNT" -eq 0 ]; then
    echo "[INFO] 无不可调度节点，跳过"
fi
echo ""

# 2. 检查所有Deployment并重启因演练而产生异常的
echo "[STEP] 检查并恢复Deployment"
for item in "${HA_DRILL_ALL[@]}"; do
    ns="${item%%/*}"
    dep="${item##*/}"
    echo "[INFO] 检查Deployment: $ns/$dep"
    
    # 检查Deployment是否存在
    if deploy_exists "$ns" "$dep"; then
        # 获取副本数
        REPLICAS=$(get_replicas "$ns" "$dep")
        RUNNING_PODS=$(get_running_pods_count "$ns" "$dep")
        
        if [ "$RUNNING_PODS" -lt "$REPLICAS" ]; then
            echo "[WARN] $ns/$dep: Pod数量不足 ($RUNNING_PODS/$REPLICAS)，尝试重启"
            kubectl rollout restart "deployment/$dep" -n "$ns" 2>/dev/null || true
        else
            echo "[INFO] $ns/$dep: Pod正常运行 ($RUNNING_PODS/$REPLICAS)"
        fi
    else
        echo "[WARN] $ns/$dep: Deployment不存在，跳过"
    fi
done
echo ""

# 3. 等待Pod恢复
echo "[STEP] 等待Pod稳定..."
sleep 10

# 4. 最终检查
echo "[STEP] 最终检查"
for item in "${HA_DRILL_ALL[@]}"; do
    ns="${item%%/*}"
    dep="${item##*/}"
    RUNNING_PODS=$(get_running_pods_count "$ns" "$dep")
    if [ "$RUNNING_PODS" -ge 1 ]; then
        echo "[INFO] $ns/$dep 服务运行正常 ($RUNNING_PODS Pod)"
    else
        echo "[ERROR] $ns/$dep 服务未恢复"
        OVERALL_SUCCESS=1
    fi
done

echo ""
if [ $OVERALL_SUCCESS -eq 0 ]; then
    echo "[INFO] 环境已全部恢复"
    echo "0"
else
    echo "[WARN] 部分资源未完全恢复，请手动检查"
    echo "1"
fi
exit 0
