#!/bin/bash
#===============================================
# K8S高可用演练脚本（单节点循环版）
# 功能：对每个工作节点逐个执行：
#       封闭(Cordon) → 排水(Drain) → 验证(Check) → 恢复(Uncordon)
# 输出：最后一行输出0（成功）/1（失败）
#===============================================

# 生产环境不建议使用 set -e，改为显式错误处理

# 导入统一配置和公共函数库
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${SCRIPT_DIR}/k8s_ha_config.sh"
source "${SCRIPT_DIR}/k8s_ha_lib.sh"

# 动态获取所有命名空间下的所有 Deployment（格式: namespace/deployment）
HA_DRILL_ALL=()
while IFS= read -r ns; do
    [ -z "$ns" ] && continue
    while IFS= read -r dep; do
        [ -n "$dep" ] && HA_DRILL_ALL+=("$ns/$dep")
    done < <(get_all_deployments "$ns")
done < <(get_all_namespaces)

echo "============================================"
echo "    K8S高可用演练（单节点循环版）"
echo "============================================"
echo "开始时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "命名空间: $(get_all_namespaces | tr '\n' ' ')"
echo "需要验证的Deployment:"
for item in "${HA_DRILL_ALL[@]}"; do
    echo "  - $item"
done
echo ""

# 获取所有非控制平面节点
TARGET_NODES=($(kubectl get nodes --no-headers 2>/dev/null | grep -v control-plane | grep Ready | awk '{print $1}'))
NODE_COUNT=${#TARGET_NODES[@]}
if [ $NODE_COUNT -eq 0 ]; then
    echo "[ERROR] 未找到可用演练节点"
    echo "1"
    exit 0
fi
echo "共有 $NODE_COUNT 个工作节点: ${TARGET_NODES[*]}"
echo ""

OVERALL_SUCCESS=0
CURRENT_NODE=0

# 先确认kubectl连接正常
echo "[STEP] 预检查：确认kubectl连接"
kubectl cluster-info > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "[ERROR] 无法连接Kubernetes集群"
    echo "1"
    exit 1
fi
echo "[INFO] Kubernetes集群连接正常"
echo ""

# ============================================================
# 逐个节点循环：封闭 → 排水 → 验证 → 恢复
# ============================================================
for NODE in "${TARGET_NODES[@]}"; do
    CURRENT_NODE=$((CURRENT_NODE + 1))
    echo "========================================="
    echo " [$CURRENT_NODE/$NODE_COUNT] 开始验证节点: $NODE"
    echo "========================================="

    # ----------------------------------------------------------
    # Step 1: 封闭节点（禁止新Pod调度上来）
    # ----------------------------------------------------------
    echo "[Step 1/4] 封闭节点 $NODE ..."
    kubectl cordon $NODE 2>/dev/null
    if [ $? -ne 0 ]; then
        echo "[WARN] 节点 $NODE 可能已被封闭"
    else
        echo "[INFO] 节点 $NODE 已封闭"
    fi

    # ----------------------------------------------------------
    # Step 2: 排水（驱逐Pod）
    # ----------------------------------------------------------
    echo "[Step 2/4] 排水节点 $NODE ..."
    kubectl drain $NODE \
        --ignore-daemonsets \
        --delete-emptydir-data \
        --force \
        --timeout=300s
    if [ $? -ne 0 ]; then
        echo "[WARN] 节点 $NODE 排水可能未完全完成"
    fi

    # ----------------------------------------------------------
    # Step 3: 验证业务是否存活（HA验证核心）
    # ----------------------------------------------------------
    echo "[Step 3/4] 验证业务恢复状态 ..."
    NODE_FAIL=0

    # 等待Pod重新调度
    sleep 10

    for item in "${HA_DRILL_ALL[@]}"; do
        ns="${item%%/*}"
        dep="${item##*/}"
        echo "  检查Deployment: $ns/$dep"

        # 检查Deployment是否存在
        if ! deploy_exists "$ns" "$dep"; then
            echo "  ❌ $ns/$dep: Deployment不存在"
            NODE_FAIL=1
            continue
        fi

        # 获取副本数
        REPLICAS=$(get_replicas "$ns" "$dep")
        if [ -z "$REPLICAS" ] || [ "$REPLICAS" -eq 0 ]; then
            echo "  ❌ $ns/$dep: 副本数为0，服务未恢复"
            NODE_FAIL=1
            continue
        fi

        # 检查Running Pod数量
        RUNNING_PODS=$(get_running_pods_count "$ns" "$dep")
        if [ "$RUNNING_PODS" -ge "$REPLICAS" ]; then
            echo "  ✅ $ns/$dep: Pod恢复正常 ($RUNNING_PODS/$REPLICAS)"
        else
            echo "  ❌ $ns/$dep: Pod未完全恢复 ($RUNNING_PODS/$REPLICAS)"
            echo "     详情:"
            kubectl get pods -n "$ns" -l app="$dep" 2>/dev/null | sed 's/^/     /'
            NODE_FAIL=1
        fi

        # 检查Pod分布（验证是否分散到其他节点）
        NODE_DIST=$(kubectl get pods -n "$ns" -l app="$dep" --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.spec.nodeName}{"\n"}{end}' 2>/dev/null | sort | uniq | wc -l | tr -d ' ')
        if [ "$NODE_DIST" -ge 2 ]; then
            echo "  ✅ $ns/$dep: Pod分布在 $NODE_DIST 个节点"
        else
            echo "  ⚠ $ns/$dep: Pod集中在同一节点"
        fi
    done

    # 检查是否有Pending Pod（集群资源是否足够）
    PENDING_COUNT=$(kubectl get pods -A --field-selector status.phase=Pending --no-headers 2>/dev/null | wc -l | tr -d ' ')
    if [ "$PENDING_COUNT" -gt 0 ]; then
        echo "  ❌ 发现 $PENDING_COUNT 个Pending Pod，集群资源不足！"
        kubectl get pods -A --field-selector status.phase=Pending -o wide 2>/dev/null
        NODE_FAIL=1
    fi

    if [ $NODE_FAIL -eq 0 ]; then
        echo "  ✅ 节点 $NODE 验证通过，业务正常运行"
    else
        echo "  ❌ 节点 $NODE 验证失败"
        OVERALL_SUCCESS=1
    fi

    # ----------------------------------------------------------
    # Step 4: 恢复节点（uncordon）
    # ----------------------------------------------------------
    echo "[Step 4/4] 恢复节点 $NODE ..."
    kubectl uncordon $NODE 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "[INFO] 节点 $NODE 已恢复调度"
    fi

    # 如果不是最后一个节点，等待一段时间再进入下一轮
    if [ $CURRENT_NODE -lt $NODE_COUNT ]; then
        echo ""
        echo "[INFO] 节点 $NODE 验证完成，${SLEEP_BETWEEN}秒后进入下一个节点..."
        sleep $SLEEP_BETWEEN
    fi

    echo ""
done

# ============================================================
# 演练总结
# ============================================================
echo "============================================"
echo "    演练完成"
echo "    总节点数: $NODE_COUNT"
if [ $OVERALL_SUCCESS -eq 0 ]; then
    echo "    结果: 全部通过 ✅"
else
    echo "    结果: 存在失败 ❌"
fi
echo "    结束时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "============================================"

if [ $OVERALL_SUCCESS -eq 0 ]; then
    echo "0"
else
    echo "1"
fi
exit 0
