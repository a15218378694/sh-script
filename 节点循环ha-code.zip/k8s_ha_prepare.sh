#!/bin/bash
#===============================================
# K8S高可用准备脚本
# 功能：演练前的环境准备（备份、扩容、标签检查、资源预留等）
# 输出：最后一行输出0（成功）/1（失败）（符合文档6要求）
#===============================================
# 生产环境不建议使用 set -e，改为显式错误处理

# 导入统一配置和公共函数库
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${SCRIPT_DIR}/k8s_ha_config.sh"
source "${SCRIPT_DIR}/k8s_ha_lib.sh"

# 动态获取所有命名空间下的所有 Deployment（格式: namespace/deployment）
HA_DRILL_ALL=()
get_all_deployments_all_ns HA_DRILL_ALL

BACKUP_DIR="/tmp/ha_backup_$(date +%Y%m%d_%H%M%S)"

echo "============================================"
echo "    K8S高可用准备"
echo "============================================"
echo "开始时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "命名空间: $(get_all_namespaces | tr '\n' ' ')"
echo "全量Deployment:"
for item in "${HA_DRILL_ALL[@]}"; do
    echo "  - $item"
done
echo "需扩容Deployment: ${HA_SCALE_DEPLOYS[*]}"
echo ""

# 0. 预检查：确认kubectl可以连接集群
echo "[STEP] 预检查：确认kubectl连接"
kubectl cluster-info --request-timeout=${KUBECTL_TIMEOUT}s > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "[ERROR] 无法连接Kubernetes集群，请检查kubeconfig配置"
    echo "1"
    exit 1
fi
echo "[INFO] Kubernetes集群连接正常"

# 0.0 恢复所有被cordon的节点（上次演练可能遗留）
echo "[STEP] 检查并恢复节点调度状态"
UNCORDON_COUNT=0
for node in $(kubectl get nodes --no-headers 2>/dev/null | grep SchedulingDisabled | awk '{print $1}'); do
    echo "[INFO] 恢复节点: $node"
    kubectl uncordon $node 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "[INFO] 节点 $node 已恢复调度"
        UNCORDON_COUNT=$((UNCORDON_COUNT + 1))
    fi
done
if [ "$UNCORDON_COUNT" -eq 0 ]; then
    echo "[INFO] 无不可调度节点"
fi
echo ""

# 0.1 前置条件检查：验证集群环境是否满足高可用要求
echo "[STEP] 前置条件检查：验证高可用环境配置"
echo ""
PRE_CHECK_FAIL=0

# 检查控制平面
CONTROL_PLANE_READY=$(kubectl get nodes -l node-role.kubernetes.io/control-plane --no-headers 2>/dev/null | grep -c Ready || echo "0")
if [ "$CONTROL_PLANE_READY" -ge 2 ]; then
    echo "[INFO] 控制平面节点正常 ($CONTROL_PLANE_READY 个)"
else
    echo "[WARN] 控制平面节点数量不足 ($CONTROL_PLANE_READY 个)"
fi

# 检查工作节点
WORKER_COUNT=$(kubectl get nodes --no-headers 2>/dev/null | grep -v control-plane | grep -c Ready || echo "0")
if [ "$WORKER_COUNT" -ge 2 ]; then
    echo "[INFO] 工作节点数量充足 ($WORKER_COUNT 个)"
else
    echo "[WARN] 工作节点数量不足 ($WORKER_COUNT 个)，建议至少2个工作节点"
fi

# 检查每个Deployment的反亲和配置和PVC（遍历所有命名空间）
for item in "${HA_DRILL_ALL[@]}"; do
    ns="${item%%/*}"
    dep="${item##*/}"
    echo "[INFO] 检查Deployment: $ns/$dep"
    
    # 检查Deployment是否存在
    if deploy_exists "$ns" "$dep"; then
        echo "[INFO] $ns/$dep Deployment存在"
        
        # 检查反亲和配置
        AFFINITY=$(kubectl get deployment "$dep" -n "$ns" -o jsonpath='{.spec.template.spec.affinity.podAntiAffinity}' 2>/dev/null)
        if [ -n "$AFFINITY" ] && [ "$AFFINITY" != "null" ]; then
            echo "[INFO] $ns/$dep: Pod反亲和配置已启用 ✅"
        else
            echo "[WARN] $ns/$dep: Pod反亲和配置未启用 ⚠️ 高可用演练建议启用反亲和"
        fi
        
        # 检查PVC是否存在且绑定
        PVC_STATUS=$(kubectl get pvc -n "$ns" -l app="$dep" -o jsonpath='{.items[*].status.phase}' 2>/dev/null | grep -c Bound || echo "0")
        if [ "$PVC_STATUS" -ge 1 ]; then
            echo "[INFO] $ns/$dep: PVC绑定正常"
        else
            echo "[INFO] $ns/$dep: 无PVC绑定（如无需持久化存储属正常）"
        fi
    else
        echo "[ERROR] $ns/$dep Deployment不存在，请先创建"
        PRE_CHECK_FAIL=1
    fi
done

if [ $PRE_CHECK_FAIL -ne 0 ]; then
    echo "[ERROR] 前置条件检查未通过，请修复后重试"
    echo "1"
    exit 1
fi
echo "[INFO] 前置条件检查完成"
echo ""

# 1. 创建备份目录
mkdir -p $BACKUP_DIR
echo "[INFO] 创建备份目录: $BACKUP_DIR"

# 2. 批量备份Deployment和Service配置（遍历所有命名空间）
echo "[STEP] 备份Deployment和Service配置"
BACKUP_FAILED=0
for item in "${HA_DRILL_ALL[@]}"; do
    ns="${item%%/*}"
    dep="${item##*/}"
    echo "[INFO] 备份Deployment: $ns/$dep"
    
    # 检查Deployment是否存在
    if deploy_exists "$ns" "$dep"; then
        # 备份Deployment
        kubectl get deployment "$dep" -n "$ns" -o yaml > "$BACKUP_DIR/${ns}_${dep}_deployment.yaml" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "[INFO] $ns/$dep Deployment配置备份成功"
        else
            echo "[WARN] $ns/$dep Deployment配置备份失败"
            BACKUP_FAILED=1
        fi
    else
        echo "[WARN] $ns/$dep Deployment不存在，跳过备份"
        BACKUP_FAILED=1
    fi
    
    # 检查Service是否存在
    if svc_exists "$ns" "$dep"; then
        # 备份Service
        kubectl get svc "$dep" -n "$ns" -o yaml > "$BACKUP_DIR/${ns}_${dep}_service.yaml" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "[INFO] $ns/$dep Service配置备份成功"
        else
            echo "[WARN] $ns/$dep Service配置备份失败"
        fi
    else
        echo "[WARN] $ns/$dep Service不存在，跳过备份"
    fi
done

if [ $BACKUP_FAILED -eq 1 ]; then
    echo "[WARN] 部分资源备份失败，请检查"
fi

# 3. 批量扩容Deployment（在天牛平台手动执行，脚本验证结果）
echo "[STEP] 扩容Deployment"
echo "[INFO] 请在天牛平台手动执行以下Deployment的扩容操作："
for item in "${HA_SCALE_DEPLOYS[@]}"; do
    ns="${item%%/*}"
    dep="${item##*/}"
    echo "  - $ns/$dep (目标副本数: $TARGET_REPLICAS)"
done
echo ""

# 验证扩容结果
echo "[INFO] 开始验证扩容结果..."
VERIFY_FAILED=0

for item in "${HA_SCALE_DEPLOYS[@]}"; do
    ns="${item%%/*}"
    dep="${item##*/}"
    echo "[INFO] 验证Deployment: $ns/$dep"
    
    # 获取当前副本数
    CURRENT_REPLICAS=$(get_replicas "$ns" "$dep")
    if [ $? -ne 0 ] || [ -z "$CURRENT_REPLICAS" ]; then
        echo "[ERROR] 获取Deployment $ns/$dep 副本数失败"
        VERIFY_FAILED=1
        continue
    fi
    
    echo "[INFO] 当前副本数: $CURRENT_REPLICAS, 目标副本数: $TARGET_REPLICAS"
    
    # 验证副本数是否达到目标
    if [ "$CURRENT_REPLICAS" -eq "$TARGET_REPLICAS" ]; then
        # 验证Running Pod数量
        RUNNING_PODS=$(get_running_pods_count "$ns" "$dep")
        if [ "$RUNNING_PODS" -eq "$TARGET_REPLICAS" ]; then
            echo "[INFO] $ns/$dep 扩容验证通过 ✅ (副本数: $CURRENT_REPLICAS, Running Pod: $RUNNING_PODS)"
        else
            echo "[WARN] $ns/$dep 副本数已达标，但Running Pod数量不足 ($RUNNING_PODS/$TARGET_REPLICAS)"
            VERIFY_FAILED=1
        fi
    else
        echo "[ERROR] $ns/$dep 副本数未达标 ($CURRENT_REPLICAS/$TARGET_REPLICAS)"
        VERIFY_FAILED=1
    fi
done

if [ $VERIFY_FAILED -ne 0 ]; then
    echo "[ERROR] 部分Deployment扩容验证失败，请检查"
    echo "1"
    exit 1
fi

# 4. 检查节点标签
echo "[STEP] 检查节点标签"
HA_NODES=$(kubectl get nodes -l ${NODE_LABEL_KEY} --no-headers 2>/dev/null | wc -l)
if [ "$HA_NODES" -ge 2 ]; then
    echo "[INFO] 高可用节点标签存在 ($HA_NODES 个)"
else
    echo "[WARN] 高可用节点标签不足，尝试添加..."
    # 示例：给第一个工作节点打标签
    FIRST_WORKER=$(kubectl get nodes --no-headers 2>/dev/null | grep -v control-plane | grep Ready | awk '{print $1}' | head -1)
    if [ -n "$FIRST_WORKER" ]; then
        kubectl label node $FIRST_WORKER ${NODE_LABEL_KEY}=true --overwrite
        echo "[INFO] 已为节点 $FIRST_WORKER 添加标签"
    fi
fi

# 5. 预留资源（示例：确保有足够CPU/Memory）
echo "[STEP] 检查资源预留"
# 此处可结合kubectl top node/pod或资源请求/限制检查，示例仅打印
echo "[INFO] 资源预留检查完成（示例）"

# 6. 清理旧备份（可选）
echo "[STEP] 清理旧备份（保留最近3次）"
ls -td /tmp/ha_backup_* 2>/dev/null | tail -n +4 | xargs rm -rf 2>/dev/null || true

# 输出结果
echo ""
echo "[INFO] 高可用准备完成"
echo "全量Deployment: ${HA_DRILL_DEPLOYS[*]}"
echo "已扩容Deployment: ${HA_SCALE_DEPLOYS[*]}"
echo "备份目录: $BACKUP_DIR"
echo "0"
exit 0
