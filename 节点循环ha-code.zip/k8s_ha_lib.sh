#!/bin/bash
#===============================================
# K8S高可用演练 - 公共函数库
# 所有脚本通过 source 引用此文件
#===============================================

# 自动扫描所有命名空间（排除系统命名空间）
# 用法: get_all_namespaces
get_all_namespaces() {
    # 排除的系统命名空间列表
    local exclude_ns=("kube-system" "kube-public" "kube-node-lease" "system")
    
    # 获取所有命名空间
    local all_ns=$(kubectl get namespace -o jsonpath='{.items[*].metadata.name}' 2>/dev/null)
    
    # 过滤排除的命名空间
    for ns in $all_ns; do
        local excluded=false
        for ex in "${exclude_ns[@]}"; do
            if [ "$ns" = "$ex" ]; then
                excluded=true
                break
            fi
        done
        [ "$excluded" = false ] && echo "$ns"
    done
}

# 动态获取指定命名空间下所有 Deployment 名称
# 用法: get_all_deployments <namespace>
get_all_deployments() {
    local ns=$1
    kubectl get deployment -n "$ns" -o jsonpath='{.items[*].metadata.name}' 2>/dev/null | tr ' ' '\n' | grep -v '^$'
}

# 获取所有命名空间下的所有 Deployment 名称（去重）
# 用法: get_all_deployments_all_ns
get_all_deployments_all_ns() {
    local -n __out="$1"
    local all_deps=()

    while IFS= read -r ns; do
        [ -z "$ns" ] && continue
        while IFS= read -r dep; do
            [ -n "$dep" ] && all_deps+=("$ns/$dep")
        done < <(get_all_deployments "$ns")
    done < <(get_all_namespaces)

    __out=("${all_deps[@]}")
}

# 获取 Deployment 当前副本数
# 用法: get_replicas <namespace> <deployment>
get_replicas() {
    local ns=$1
    local dep=$2
    kubectl get deployment "$dep" -n "$ns" \
        --request-timeout="${KUBECTL_TIMEOUT}s" \
        -o jsonpath='{.spec.replicas}' 2>/dev/null
}

# 获取 Deployment 的 Running Pod 数量
# 用法: get_running_pods_count <namespace> <deployment>
get_running_pods_count() {
    local ns=$1
    local dep=$2
    kubectl get pods -n "$ns" -l app="$dep" \
        --field-selector status.phase=Running \
        --no-headers 2>/dev/null | wc -l | tr -d ' '
}

# 检查 Deployment 是否存在
# 用法: deploy_exists <namespace> <deployment>
deploy_exists() {
    local ns=$1
    local dep=$2
    kubectl get deployment "$dep" -n "$ns" &>/dev/null
}

# 检查 Service 是否存在
# 用法: svc_exists <namespace> <service>
svc_exists() {
    local ns=$1
    local svc=$2
    kubectl get svc "$svc" -n "$ns" &>/dev/null
}

# 遍历所有命名空间执行命令的辅助函数
# 用法: for_each_namespace <function_name> [args...]
for_each_namespace() {
    local func=$1
    shift
    while IFS= read -r ns; do
        [ -z "$ns" ] && continue
        "$func" "$ns" "$@"
    done < <(get_all_namespaces)
}
