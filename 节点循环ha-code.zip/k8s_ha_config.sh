#!/bin/bash
#===============================================
# K8S高可用演练 - 统一配置
# 所有脚本通过 source 引用此文件
#===============================================

# 命名空间列表（自动扫描，无需手动配置）
# 脚本将自动获取集群中所有非系统命名空间的列表
# 如需排除特定命名空间，请在 k8s_ha_lib.sh 的 get_all_namespaces 函数中配置

# 需要执行扩容操作的 Deployment 列表（格式：namespace/deployment）
# 演练/检查/恢复不依赖此列表，动态发现所有命名空间下的全量deploy
# 每行写一个，方便增删
HA_SCALE_DEPLOYS=(
    "default/nginx-ha"
    "default/nginx-ha2"
)

# 目标副本数（扩容到多少副本）
TARGET_REPLICAS=3

# kubectl 请求超时时间（秒）
KUBECTL_TIMEOUT=30

# 高可用节点标签键
NODE_LABEL_KEY="high-availability"

# 每轮演练间休眠秒数
SLEEP_BETWEEN=30
