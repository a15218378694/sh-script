#!/bin/bash
#===============================================
# K8S高可用演练 - 完整性检查脚本
# 功能：验证HA演练的完整性，生成演练报告
# 输出：最后一行输出0（成功）/1（失败）（符合文档6要求）
#===============================================

# 生产环境不建议使用 set -e，改为显式错误处理

# 导入统一配置和公共函数库
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${SCRIPT_DIR}/k8s_ha_config.sh"
source "${SCRIPT_DIR}/k8s_ha_lib.sh"

# 动态获取所有命名空间下的所有 Deployment（格式: namespace/deployment）
HA_DRILL_ALL=()
get_all_deployments_all_ns HA_DRILL_ALL

# 颜色定义
RED='\033[31m'
GREEN='\033[32m'
YELLOW='\033[33m'
BLUE='\033[34m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step() { echo -e "${BLUE}[STEP]${NC} $1"; }

# 检查项计数
CHECK_PASS=0
CHECK_WARN=0
CHECK_FAIL=0

check_item() {
    local desc=$1
    local status=$2
    case $status in
        pass)
            echo -e "  ✓ $desc"
            CHECK_PASS=$((CHECK_PASS + 1))
            ;;
        warn)
            echo -e "  ⚠ $desc"
            CHECK_WARN=$((CHECK_WARN + 1))
            ;;
        fail)
            echo -e "  ✗ $desc"
            CHECK_FAIL=$((CHECK_FAIL + 1))
            ;;
    esac
}

#--------------------------------------------
# 主流程
#--------------------------------------------
echo "============================================"
echo "    K8S高可用演练 - 完整性检查"
echo "============================================"
echo "检查时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

#--------------------------------------------
# 1. 集群基础检查
#--------------------------------------------
log_step "【1】集群基础检查"
echo ""

# 检查控制平面
CONTROL_PLANE_READY=$(kubectl get nodes -l node-role.kubernetes.io/control-plane --no-headers 2>/dev/null | grep -c ' Ready' || true)
if [ "$CONTROL_PLANE_READY" -gt 0 ]; then
    check_item "控制平面节点正常 ($CONTROL_PLANE_READY)" "pass"
else
    check_item "控制平面节点异常" "fail"
fi

# 检查工作节点
WORKER_COUNT=$(kubectl get nodes --no-headers 2>/dev/null | grep -v control-plane | grep -c ' Ready' || true)
if [ "$WORKER_COUNT" -ge 2 ]; then
    check_item "工作节点数量充足 ($WORKER_COUNT)" "pass"
else
    check_item "工作节点数量不足 ($WORKER_COUNT)" "warn"
fi

#--------------------------------------------
# 2. 演练后恢复验证 - Pod状态检查
#--------------------------------------------
log_step "【2】Pod恢复状态检查"
echo ""

OVERALL_CHECK_FAIL=0

for item in "${HA_DRILL_ALL[@]}"; do
    ns="${item%%/*}"
    dep="${item##*/}"
    echo "验证Deployment: $ns/$dep"
    
    # 检查Deployment是否存在
    if ! deploy_exists "$ns" "$dep"; then
        check_item "$ns/$dep: Deployment 不存在" "fail"
        OVERALL_CHECK_FAIL=1
        continue
    fi
    
    # 获取副本数
    REPLICAS=$(get_replicas "$ns" "$dep")
    if [ -z "$REPLICAS" ] || [ "$REPLICAS" -eq 0 ]; then
        check_item "$ns/$dep: 副本数为0，服务未恢复" "fail"
        OVERALL_CHECK_FAIL=1
        continue
    fi
    
    # 检查Running Pod数量是否达标
    RUNNING_PODS=$(get_running_pods_count "$ns" "$dep")
    if [ "$RUNNING_PODS" -ge "$REPLICAS" ]; then
        check_item "$ns/$dep: 所有Pod运行正常 ($RUNNING_PODS/$REPLICAS)" "pass"
    else
        check_item "$ns/$dep: Pod数量未恢复 ($RUNNING_PODS/$REPLICAS)" "fail"
        OVERALL_CHECK_FAIL=1
    fi

    # 检查Pod分布（验证调度到多个节点）
    NODE_DIST=$(kubectl get pods -n "$ns" -l app="$dep" --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.spec.nodeName}{"\n"}{end}' 2>/dev/null | sort | uniq | wc -l | tr -d ' ')
    if [ "$NODE_DIST" -ge 2 ]; then
        check_item "$ns/$dep: Pod分布在不同节点 ($NODE_DIST 个节点)" "pass"
    else
        check_item "$ns/$dep: Pod集中在同一节点 ($NODE_DIST)" "warn"
    fi

    # 检查Pod重启次数（故障注入的影响）
    RESTART_COUNT=$(kubectl get pods -n "$ns" -l app="$dep" -o jsonpath='{range .items[*]}{.status.containerStatuses[0].restartCount}{"\n"}{end}' 2>/dev/null | awk '{sum+=$1}END{print sum+0}')
    if [ -z "$RESTART_COUNT" ]; then
        RESTART_COUNT=0
    fi
    if [ "$RESTART_COUNT" -eq 0 ]; then
        check_item "$ns/$dep: Pod无重启" "pass"
    else
        check_item "$ns/$dep: Pod重启次数 ($RESTART_COUNT 次)" "warn"
    fi
    
    echo ""
done

#--------------------------------------------
# 3. 网络与服务恢复检查
#--------------------------------------------
log_step "【3】网络与服务恢复检查"
echo ""

for item in "${HA_DRILL_ALL[@]}"; do
    ns="${item%%/*}"
    dep="${item##*/}"
    echo "验证Deployment: $ns/$dep 的网络与服务"

    # 获取副本数
    REPLICAS=$(get_replicas "$ns" "$dep")

    # 检查Service是否存在（无Service的Deployment跳过，不计入失败）
    if svc_exists "$ns" "$dep"; then
        check_item "$ns/$dep: Service 存在" "pass"

        # 检查Endpoint是否有后端Pod
        ENDPOINT_COUNT=$(kubectl get endpoints "$dep" -n "$ns" -o jsonpath='{.subsets[*].addresses[*].ip}' 2>/dev/null | wc -w | tr -d ' ')
        if [ "$ENDPOINT_COUNT" -ge 1 ]; then
            check_item "$ns/$dep: Endpoint正常 ($ENDPOINT_COUNT 个后端)" "pass"
        else
            check_item "$ns/$dep: Endpoint无后端Pod" "fail"
            OVERALL_CHECK_FAIL=1
        fi
    else
        check_item "$ns/$dep: 无Service（可能无需暴露）" "warn"
    fi
    
    echo ""
done

#--------------------------------------------
# 4. 节点状态检查
#--------------------------------------------
log_step "【4】节点状态检查"
echo ""

# 检查节点是否全部Ready
NODE_READY=$(kubectl get nodes --no-headers 2>/dev/null | grep -c ' Ready' || true)
TOTAL_NODES=$(kubectl get nodes --no-headers 2>/dev/null | wc -l | tr -d ' ')
SCHED_DISABLED=$(kubectl get nodes --no-headers 2>/dev/null | grep -c SchedulingDisabled || true)
check_item "节点总数: $TOTAL_NODES, Ready: $NODE_READY" "pass"
if [ "$SCHED_DISABLED" -gt 0 ]; then
    check_item "存在不可调度节点 ($SCHED_DISABLED 个)" "warn"
fi

# 检查是否有高可用标签节点
HA_NODES=$(kubectl get nodes -l $NODE_LABEL_KEY --no-headers 2>/dev/null | wc -l | tr -d ' ')
if [ "$HA_NODES" -ge 2 ]; then
    check_item "高可用节点标签存在 ($HA_NODES 个)" "pass"
else
    check_item "高可用节点标签不足 ($HA_NODES 个)" "warn"
fi

#--------------------------------------------
# 总结与输出
#--------------------------------------------
echo ""
echo "============================================"
echo "    检查完成"
echo "    通过: $CHECK_PASS"
echo "    警告: $CHECK_WARN"
echo "    失败: $CHECK_FAIL"
echo "============================================"

if [ "$OVERALL_CHECK_FAIL" -eq 0 ] && [ "$CHECK_FAIL" -eq 0 ]; then
    echo "0"
else
    echo "1"
fi
exit 0